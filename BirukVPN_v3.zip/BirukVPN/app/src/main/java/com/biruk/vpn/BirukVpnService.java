package com.biruk.vpn;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Set;

public class BirukVpnService extends VpnService {
    public static final String ACTION_START = "com.biruk.vpn.START";

    private final Object lock = new Object();
    private volatile boolean running = false;
    private Tunnel tunnel;
    private ParcelFileDescriptor tun;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || !ACTION_START.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startForegroundCompat();
        teardown();

        final String name = intent.getStringExtra("name");
        final String host = intent.getStringExtra("host");
        final String key = intent.getStringExtra("key");
        final String pin = intent.getStringExtra("pin");
        final String sni = intent.getStringExtra("sni");
        int p = 443;
        try {
            p = Integer.parseInt(intent.getStringExtra("port"));
        } catch (Exception ignored) {
        }
        final int port = p;

        VpnState.rx = 0;
        VpnState.tx = 0;
        VpnState.status = VpnState.CONNECTING;
        running = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                runTunnel(name, host, port, key, pin, sni);
            }
        }, "biruk-vpn").start();
        return START_NOT_STICKY;
    }

    private void runTunnel(String name, String host, int port, String key, String pin, String sni) {
        try {
            VpnState.log("Server: " + name + " (" + host + ":" + port + ")");
            VpnState.log("Package host/SNI: " + sni);
            VpnState.log("Opening TLS tunnel...");
            final Tunnel t = Tunnel.open(this, host, port, sni, key, pin);
            synchronized (lock) {
                if (!running) {
                    t.close();
                    return;
                }
                tunnel = t;
            }
            VpnState.log("Tunnel authenticated");

            Builder b = new Builder();
            b.setSession("Biruk VPN");
            b.setMtu(1400);
            b.addAddress("10.8.0.2", 32);
            b.addRoute("0.0.0.0", 0);
            b.addAddress("fd00:8::2", 128);   // IPv6 is captured and dropped by the server (prevents leaks)
            b.addRoute("::", 0);
            if (Store.getDns(this)) {
                b.addDnsServer("1.1.1.1");
                b.addDnsServer("1.0.0.1");
            } else {
                b.addDnsServer("8.8.8.8");
                b.addDnsServer("8.8.4.4");
            }
            Set<String> apps = Store.getAllowedApps(this);
            if (!apps.isEmpty()) {
                for (String pkg : apps) {
                    try {
                        b.addAllowedApplication(pkg);
                    } catch (PackageManager.NameNotFoundException ignored) {
                    }
                }
                VpnState.log("Split tunneling: " + apps.size() + " app(s) use the VPN");
            }
            b.setBlocking(true);
            ParcelFileDescriptor fd = b.establish();
            if (fd == null) throw new IOException("VPN permission was revoked");
            synchronized (lock) {
                tun = fd;
            }
            VpnState.startTime = System.currentTimeMillis();
            VpnState.status = VpnState.CONNECTED;
            VpnState.log("VPN connected");

            final FileOutputStream tunOut = new FileOutputStream(fd.getFileDescriptor());
            Thread reader = new Thread(new Runnable() {
                @Override
                public void run() {
                    byte[] buf = new byte[65535];
                    try {
                        while (running) {
                            int n = t.recv(buf);
                            if (n > 0) {
                                tunOut.write(buf, 0, n);
                                VpnState.rx += n;
                            }
                        }
                    } catch (Exception e) {
                        if (running) VpnState.log("Connection lost: " + msg(e));
                    } finally {
                        teardown();
                    }
                }
            }, "biruk-vpn-rx");
            reader.start();

            FileInputStream tunIn = new FileInputStream(fd.getFileDescriptor());
            byte[] pkt = new byte[32767];
            while (running) {
                int n = tunIn.read(pkt);
                if (n < 0) break;
                if (n > 0) {
                    t.send(pkt, n);
                    VpnState.tx += n;
                }
            }
        } catch (Exception e) {
            if (running) VpnState.log("Error: " + msg(e));
        } finally {
            teardown();
        }
    }

    private static String msg(Exception e) {
        return e.getMessage() != null ? e.getMessage() : e.toString();
    }

    /** Idempotent: closes tunnel + TUN, resets state, stops the service if a session was active. */
    private void teardown() {
        boolean was;
        synchronized (lock) {
            was = running;
            running = false;
            if (tunnel != null) {
                tunnel.close();
                tunnel = null;
            }
            if (tun != null) {
                try {
                    tun.close();
                } catch (IOException ignored) {
                }
                tun = null;
            }
        }
        VpnState.status = VpnState.DISCONNECTED;
        if (was) {
            VpnState.log("Disconnected");
            stopForeground(true);
            stopSelf();
        }
    }

    private void startForegroundCompat() {
        Notification.Builder nb;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel("biruk_vpn", "VPN status",
                    NotificationManager.IMPORTANCE_LOW));
            nb = new Notification.Builder(this, "biruk_vpn");
        } else {
            nb = new Notification.Builder(this);
        }
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), 0);
        nb.setContentTitle("Biruk VPN")
                .setContentText("VPN is running")
                .setSmallIcon(R.drawable.ic_shield_on)
                .setContentIntent(pi);
        startForeground(1, nb.build());
    }

    @Override
    public void onRevoke() {
        VpnState.log("VPN revoked by system");
        teardown();
        super.onRevoke();
    }

    @Override
    public void onDestroy() {
        teardown();
        super.onDestroy();
    }
}
