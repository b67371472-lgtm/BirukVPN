package com.biruk.vpn;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Shared connection state + in-memory log (read by the UI, written by the service). */
public class VpnState {
    public static final int DISCONNECTED = 0;
    public static final int CONNECTING = 1;
    public static final int CONNECTED = 2;

    public static volatile int status = DISCONNECTED;
    public static volatile long rx = 0;
    public static volatile long tx = 0;
    public static volatile long startTime = 0;

    private static final StringBuilder LOG = new StringBuilder();
    private static final SimpleDateFormat FMT = new SimpleDateFormat("HH:mm:ss", Locale.US);

    public static synchronized void log(String msg) {
        LOG.append(FMT.format(new Date())).append("  ").append(msg).append('\n');
        if (LOG.length() > 20000) {
            LOG.delete(0, 5000);
        }
    }

    public static synchronized String getLog() {
        return LOG.toString();
    }

    public static synchronized void clearLog() {
        LOG.setLength(0);
    }
}
