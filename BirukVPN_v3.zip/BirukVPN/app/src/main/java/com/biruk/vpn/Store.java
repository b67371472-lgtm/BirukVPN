package com.biruk.vpn;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Persistent settings: packages (name|sni), servers (name|host|port|key|pin), toggles. */
public class Store {
    private static final String PREFS = "biruk_vpn";

    private static final String DEFAULT_PACKAGES =
            "Telegram Package 01|t.me\n"
            + "Telegram Package 02|t.me\n"
            + "Telegram Package 03|t.me\n"
            + "TikTok Package 01|tiktok.com\n"
            + "YouTube Package 01|youtube.com\n"
            + "Spotify Package 01|spotify.com";

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static List<String[]> parse(String raw, int n) {
        List<String[]> out = new ArrayList<String[]>();
        for (String line : raw.split("\n")) {
            if (line.trim().length() == 0) continue;
            String[] p = line.split("\\|", -1);
            String[] f = new String[n];
            for (int i = 0; i < n; i++) f[i] = i < p.length ? p[i] : "";
            out.add(f);
        }
        return out;
    }

    private static String join(List<String[]> list) {
        StringBuilder sb = new StringBuilder();
        for (String[] f : list) {
            for (int i = 0; i < f.length; i++) {
                if (i > 0) sb.append('|');
                sb.append(f[i]);
            }
            sb.append('\n');
        }
        return sb.toString();
    }

    // ---- packages
    public static List<String[]> getPackages(Context c) {
        List<String[]> l = parse(sp(c).getString("packages", DEFAULT_PACKAGES), 2);
        if (l.isEmpty()) l = parse(DEFAULT_PACKAGES, 2);
        return l;
    }

    public static void setPackages(Context c, List<String[]> l) {
        sp(c).edit().putString("packages", join(l)).apply();
    }

    public static int getSelectedPackage(Context c) {
        int i = sp(c).getInt("pkg", 0);
        int size = getPackages(c).size();
        return (i < 0 || i >= size) ? 0 : i;
    }

    public static void setSelectedPackage(Context c, int i) {
        sp(c).edit().putInt("pkg", i).apply();
    }

    // ---- servers
    public static List<String[]> getServers(Context c) {
        return parse(sp(c).getString("servers", ""), 5);
    }

    public static void setServers(Context c, List<String[]> l) {
        sp(c).edit().putString("servers", join(l)).apply();
    }

    /** -1 = Auto Select (random). */
    public static int getSelectedServer(Context c) {
        int i = sp(c).getInt("srv", -1);
        return (i >= getServers(c).size()) ? -1 : i;
    }

    public static void setSelectedServer(Context c, int i) {
        sp(c).edit().putInt("srv", i).apply();
    }

    // ---- DNS toggle
    public static boolean getDns(Context c) {
        return sp(c).getBoolean("dns", false);
    }

    public static void setDns(Context c, boolean on) {
        sp(c).edit().putBoolean("dns", on).apply();
    }

    // ---- split tunneling (empty set = all apps use the VPN)
    public static Set<String> getAllowedApps(Context c) {
        return new HashSet<String>(sp(c).getStringSet("apps", new HashSet<String>()));
    }

    public static void setAllowedApps(Context c, Set<String> apps) {
        sp(c).edit().putStringSet("apps", apps).apply();
    }
}
