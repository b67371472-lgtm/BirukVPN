package com.biruk.vpn;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

/** List adapter for the package/server pickers. The selected row gets a green background. */
class ChoiceAdapter extends BaseAdapter {
    private final LayoutInflater inflater;
    private final List<String[]> items; // {title, subtitle}
    private final int selected;

    ChoiceAdapter(Context ctx, List<String[]> items, int selected) {
        this.inflater = LayoutInflater.from(ctx);
        this.items = items;
        this.selected = selected;
    }

    @Override public int getCount() { return items.size(); }
    @Override public Object getItem(int position) { return items.get(position); }
    @Override public long getItemId(int position) { return position; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView != null ? convertView : inflater.inflate(R.layout.item_choice, parent, false);
        String[] it = items.get(position);
        ((TextView) v.findViewById(R.id.itemTitle)).setText(it[0]);
        ((TextView) v.findViewById(R.id.itemSub)).setText(it[1]);
        v.setBackgroundResource(position == selected ? R.drawable.bg_item_selected : R.drawable.bg_item);
        return v;
    }
}
