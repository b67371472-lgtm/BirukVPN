package com.biruk.vpn;

import android.net.VpnService;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Collections;

import javax.net.ssl.SNIHostName;
import javax.net.ssl.SNIServerName;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * TLS tunnel to the Biruk relay server.
 * - TLS ClientHello carries the chosen package host as SNI.
 * - Server certificate is verified by SHA-256 pin (not by hostname), so the SNI can differ from the real server.
 * - Frames: 2-byte big-endian length + raw IP packet. First frame = access key, server answers "OK".
 */
public class Tunnel {
    private final SSLSocket socket;
    private final DataInputStream in;
    private final OutputStream out;

    private Tunnel(SSLSocket s) throws IOException {
        this.socket = s;
        this.in = new DataInputStream(new BufferedInputStream(s.getInputStream(), 65536));
        this.out = s.getOutputStream();
    }

    public static Tunnel open(VpnService svc, String host, int port, String sni, String key, String pin)
            throws Exception {
        Socket raw = new Socket();
        if (!svc.protect(raw)) {
            raw.close();
            throw new IOException("Could not protect socket from VPN routing");
        }
        raw.setKeepAlive(true);
        raw.setTcpNoDelay(true);
        raw.connect(new InetSocketAddress(host, port), 10000);

        SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(null, new TrustManager[]{new PinTrust(pin)}, null);
        SSLSocket s = (SSLSocket) ctx.getSocketFactory().createSocket(raw, sni, port, true);
        try {
            SSLParameters p = s.getSSLParameters();
            p.setServerNames(Collections.<SNIServerName>singletonList(new SNIHostName(sni)));
            s.setSSLParameters(p);
        } catch (IllegalArgumentException e) {
            VpnState.log("SNI '" + sni + "' is not a valid host name; using default");
        }
        s.setSoTimeout(10000);
        s.startHandshake();

        Tunnel t = new Tunnel(s);
        byte[] k = key.getBytes("UTF-8");
        t.send(k, k.length);
        try {
            byte[] buf = new byte[256];
            int n = t.recv(buf);
            if (!"OK".equals(new String(buf, 0, n, "UTF-8"))) {
                s.close();
                throw new IOException("Server rejected the access key");
            }
        } catch (EOFException e) {
            s.close();
            throw new IOException("Server closed the connection (wrong access key?)");
        }
        s.setSoTimeout(0);
        return t;
    }

    public void send(byte[] buf, int len) throws IOException {
        byte[] f = new byte[len + 2];
        f[0] = (byte) ((len >> 8) & 0xff);
        f[1] = (byte) (len & 0xff);
        System.arraycopy(buf, 0, f, 2, len);
        synchronized (out) {
            out.write(f);
            out.flush();
        }
    }

    /** buf must be at least 65535 bytes. Returns payload length (0 = keep-alive). */
    public int recv(byte[] buf) throws IOException {
        int len = in.readUnsignedShort();
        in.readFully(buf, 0, len);
        return len;
    }

    public void close() {
        try {
            socket.close();
        } catch (Exception ignored) {
        }
    }

    /** Accepts only the server certificate whose SHA-256 fingerprint equals the configured pin. */
    private static class PinTrust implements X509TrustManager {
        private final String pin;

        PinTrust(String pin) {
            this.pin = pin == null ? "" : pin.replace(":", "").replace(" ", "").toLowerCase();
        }

        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
            throw new CertificateException("Client certificates not supported");
        }

        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
            if (pin.length() == 0) {
                throw new CertificateException("No certificate fingerprint (pin) set for this server");
            }
            try {
                byte[] d = MessageDigest.getInstance("SHA-256").digest(chain[0].getEncoded());
                StringBuilder sb = new StringBuilder();
                for (byte b : d) sb.append(String.format("%02x", b));
                if (!sb.toString().equals(pin)) {
                    throw new CertificateException("Server certificate does not match the pinned fingerprint");
                }
            } catch (CertificateException e) {
                throw e;
            } catch (Exception e) {
                throw new CertificateException(e.toString());
            }
        }

        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return new X509Certificate[0];
        }
    }
}
