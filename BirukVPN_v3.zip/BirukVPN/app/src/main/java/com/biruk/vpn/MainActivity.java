package com.biruk.vpn;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.CompoundButton;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int REQ_VPN = 100;
    private static final String TELEGRAM_URL = "https://t.me/your_channel_here"; // TODO: your channel

    private final Handler handler = new Handler();
    private TextView tvIp, tvRx, tvTx, tvStatus, tvStatusSub, tvDuration;
    private TextView tvPackage, tvSni, tvServer, tvServerSub, tvDns, tvBtn;
    private ImageView ivStatus;
    private View btnConnect;
    private Switch swDns;

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            updateUi();
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvIp = (TextView) findViewById(R.id.tvIp);
        tvRx = (TextView) findViewById(R.id.tvRx);
        tvTx = (TextView) findViewById(R.id.tvTx);
        tvStatus = (TextView) findViewById(R.id.tvStatus);
        tvStatusSub = (TextView) findViewById(R.id.tvStatusSub);
        tvDuration = (TextView) findViewById(R.id.tvDuration);
        tvPackage = (TextView) findViewById(R.id.tvPackage);
        tvSni = (TextView) findViewById(R.id.tvSni);
        tvServer = (TextView) findViewById(R.id.tvServer);
        tvServerSub = (TextView) findViewById(R.id.tvServerSub);
        tvDns = (TextView) findViewById(R.id.tvDns);
        tvBtn = (TextView) findViewById(R.id.tvBtn);
        ivStatus = (ImageView) findViewById(R.id.ivStatus);
        btnConnect = findViewById(R.id.btnConnect);
        swDns = (Switch) findViewById(R.id.swDns);

        findViewById(R.id.btnMenu).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showMenu(v); }
        });
        findViewById(R.id.btnBell).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showLog(); }
        });
        findViewById(R.id.cardNetwork).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showPackageDialog(); }
        });
        findViewById(R.id.cardServer).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showServerDialog(); }
        });
        btnConnect.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { onConnectClicked(); }
        });

        swDns.setChecked(Store.getDns(this));
        swDns.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                Store.setDns(MainActivity.this, checked);
                refreshSelections();
                if (VpnState.status != VpnState.DISCONNECTED) {
                    toast("DNS change applies on next connection");
                }
            }
        });
        refreshSelections();
    }

    @Override
    protected void onResume() {
        super.onResume();
        tvIp.setText(localIp());
        handler.post(ticker);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(ticker);
    }

    // ------------------------------------------------------------------ UI state

    private void refreshSelections() {
        List<String[]> pk = Store.getPackages(this);
        String[] p = pk.get(Store.getSelectedPackage(this));
        tvPackage.setText("\uD83C\uDF10 " + p[0]);
        tvSni.setText("SNI: " + p[1]);

        List<String[]> servers = Store.getServers(this);
        int s = Store.getSelectedServer(this);
        if (s < 0) {
            tvServer.setText("Auto Select Server");
            tvServerSub.setText("Random" + (servers.isEmpty() ? " (no servers added yet)" : ""));
        } else {
            tvServer.setText(servers.get(s)[0]);
            tvServerSub.setText(servers.get(s)[1] + ":" + servers.get(s)[2]);
        }
        tvDns.setText(Store.getDns(this) ? "DNS (Cloudflare 1.1.1.1)" : "DNS (Default DNS)");
    }

    private void updateUi() {
        int st = VpnState.status;
        tvRx.setText(fmt(VpnState.rx));
        tvTx.setText(fmt(VpnState.tx));
        if (st == VpnState.CONNECTED) {
            ivStatus.setImageResource(R.drawable.ic_shield_on);
            tvStatus.setText("Connected");
            tvStatus.setTextColor(0xFF00E676);
            tvStatusSub.setText("Your connection is secure");
            btnConnect.setBackgroundResource(R.drawable.bg_btn_stop);
            tvBtn.setText("STOP");
            long s = (System.currentTimeMillis() - VpnState.startTime) / 1000;
            tvDuration.setText(String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60));
        } else if (st == VpnState.CONNECTING) {
            ivStatus.setImageResource(R.drawable.ic_shield_off);
            tvStatus.setText("Connecting...");
            tvStatus.setTextColor(0xFFFFB300);
            tvStatusSub.setText("Please wait");
            btnConnect.setBackgroundResource(R.drawable.bg_btn_stop);
            tvBtn.setText("CANCEL");
            tvDuration.setText("00:00:00");
        } else {
            ivStatus.setImageResource(R.drawable.ic_shield_off);
            tvStatus.setText("Disconnected");
            tvStatus.setTextColor(0xFFFF4D4D);
            tvStatusSub.setText("Your connection is not secure");
            btnConnect.setBackgroundResource(R.drawable.bg_btn_start);
            tvBtn.setText("START");
            tvDuration.setText("00:00:00");
        }
    }

    private static String fmt(long b) {
        if (b < 1024) return b + " B";
        if (b < 1048576L) return String.format(Locale.US, "%.1f KB", b / 1024.0);
        if (b < 1073741824L) return String.format(Locale.US, "%.1f MB", b / 1048576.0);
        return String.format(Locale.US, "%.2f GB", b / 1073741824.0);
    }

    // ------------------------------------------------------------------ connect / disconnect

    private void onConnectClicked() {
        if (VpnState.status != VpnState.DISCONNECTED) {
            stopService(new Intent(this, BirukVpnService.class));
            VpnState.log("Stopped by user");
            return;
        }
        Intent prep = VpnService.prepare(this);
        if (prep != null) {
            startActivityForResult(prep, REQ_VPN);
        } else {
            startVpn();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_VPN) {
            if (res == RESULT_OK) {
                startVpn();
            } else {
                VpnState.log("VPN permission denied");
                toast("VPN permission denied");
            }
        }
    }

    private void startVpn() {
        List<String[]> servers = Store.getServers(this);
        if (servers.isEmpty()) {
            VpnState.log("No server configured. Add one in the SERVER card.");
            toast("Add a server first");
            showServerDialog();
            return;
        }
        int sel = Store.getSelectedServer(this);
        String[] s = (sel >= 0 && sel < servers.size())
                ? servers.get(sel)
                : servers.get(new Random().nextInt(servers.size()));
        String sni = Store.getPackages(this).get(Store.getSelectedPackage(this))[1];

        Intent i = new Intent(this, BirukVpnService.class);
        i.setAction(BirukVpnService.ACTION_START);
        i.putExtra("name", s[0]);
        i.putExtra("host", s[1]);
        i.putExtra("port", s[2]);
        i.putExtra("key", s[3]);
        i.putExtra("pin", s[4]);
        i.putExtra("sni", sni);
        VpnState.status = VpnState.CONNECTING;
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(i);
        } else {
            startService(i);
        }
    }

    private boolean busy() {
        if (VpnState.status != VpnState.DISCONNECTED) {
            toast("Disconnect first to change this");
            return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ package picker

    private void showPackageDialog() {
        if (busy()) return;
        List<String[]> pk = Store.getPackages(this);
        List<String[]> items = new ArrayList<String[]>();
        for (String[] p : pk) items.add(new String[]{"\uD83C\uDF10 " + p[0], "SNI: " + p[1]});

        ListView lv = makeList();
        lv.setAdapter(new ChoiceAdapter(this, items, Store.getSelectedPackage(this)));
        final AlertDialog dlg = new AlertDialog.Builder(this, R.style.DarkDialog)
                .setTitle("Network Package (long-press to edit)")
                .setView(lv)
                .setNeutralButton("Add", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { editPackage(-1); }
                })
                .setNegativeButton("Close", null)
                .create();
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
                Store.setSelectedPackage(MainActivity.this, pos);
                refreshSelections();
                dlg.dismiss();
            }
        });
        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int pos, long id) {
                dlg.dismiss();
                editPackage(pos);
                return true;
            }
        });
        dlg.show();
    }

    private void editPackage(final int idx) {
        final List<String[]> pk = Store.getPackages(this);
        String[] cur = idx >= 0 ? pk.get(idx) : new String[]{"", ""};
        LinearLayout box = vbox();
        final EditText fName = addField(box, "Package name (e.g. Telegram Package 04)", cur[0]);
        final EditText fSni = addField(box, "Host / SNI (e.g. t.me)", cur[1]);
        AlertDialog.Builder b = new AlertDialog.Builder(this, R.style.DarkDialog)
                .setTitle(idx >= 0 ? "Edit Package" : "Add Package")
                .setView(box)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String n = clean(fName.getText().toString());
                        String s = clean(fSni.getText().toString());
                        if (n.length() == 0 || s.length() == 0) {
                            toast("Name and host are required");
                            return;
                        }
                        String[] e = new String[]{n, s};
                        if (idx >= 0) pk.set(idx, e); else pk.add(e);
                        Store.setPackages(MainActivity.this, pk);
                        refreshSelections();
                    }
                })
                .setNegativeButton("Cancel", null);
        if (idx >= 0 && pk.size() > 1) {
            b.setNeutralButton("Delete", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface d, int w) {
                    int sel = Store.getSelectedPackage(MainActivity.this);
                    pk.remove(idx);
                    Store.setPackages(MainActivity.this, pk);
                    if (sel == idx) sel = 0; else if (sel > idx) sel--;
                    Store.setSelectedPackage(MainActivity.this, sel);
                    refreshSelections();
                }
            });
        }
        b.show();
    }

    // ------------------------------------------------------------------ server picker

    private void showServerDialog() {
        if (busy()) return;
        List<String[]> servers = Store.getServers(this);
        List<String[]> items = new ArrayList<String[]>();
        items.add(new String[]{"\uD83C\uDFB2 Auto Select Server", "Random"});
        for (String[] s : servers) items.add(new String[]{s[0], s[1] + ":" + s[2]});

        ListView lv = makeList();
        lv.setAdapter(new ChoiceAdapter(this, items, Store.getSelectedServer(this) + 1));
        final AlertDialog dlg = new AlertDialog.Builder(this, R.style.DarkDialog)
                .setTitle("Server (long-press to edit)")
                .setView(lv)
                .setNeutralButton("Add", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { editServer(-1); }
                })
                .setNegativeButton("Close", null)
                .create();
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
                Store.setSelectedServer(MainActivity.this, pos - 1);
                refreshSelections();
                dlg.dismiss();
            }
        });
        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int pos, long id) {
                if (pos == 0) return true;
                dlg.dismiss();
                editServer(pos - 1);
                return true;
            }
        });
        dlg.show();
    }

    private void editServer(final int idx) {
        final List<String[]> servers = Store.getServers(this);
        String[] cur = idx >= 0 ? servers.get(idx) : new String[]{"", "", "443", "", ""};
        LinearLayout box = vbox();
        final EditText fName = addField(box, "Name", cur[0]);
        final EditText fHost = addField(box, "Server host or IP", cur[1]);
        final EditText fPort = addField(box, "Port (e.g. 443)", cur[2]);
        fPort.setInputType(InputType.TYPE_CLASS_NUMBER);
        final EditText fKey = addField(box, "Access key (secret)", cur[3]);
        final EditText fPin = addField(box, "Certificate SHA-256 fingerprint", cur[4]);
        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        AlertDialog.Builder b = new AlertDialog.Builder(this, R.style.DarkDialog)
                .setTitle(idx >= 0 ? "Edit Server" : "Add Server")
                .setView(sv)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String n = clean(fName.getText().toString());
                        String h = clean(fHost.getText().toString());
                        String p = clean(fPort.getText().toString());
                        String k = clean(fKey.getText().toString());
                        String f = clean(fPin.getText().toString());
                        if (n.length() == 0) n = h;
                        if (h.length() == 0 || k.length() == 0 || f.length() == 0) {
                            toast("Host, access key and fingerprint are required");
                            return;
                        }
                        if (p.length() == 0) p = "443";
                        String[] e = new String[]{n, h, p, k, f};
                        if (idx >= 0) servers.set(idx, e); else servers.add(e);
                        Store.setServers(MainActivity.this, servers);
                        refreshSelections();
                    }
                })
                .setNegativeButton("Cancel", null);
        if (idx >= 0) {
            b.setNeutralButton("Delete", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface d, int w) {
                    servers.remove(idx);
                    Store.setServers(MainActivity.this, servers);
                    Store.setSelectedServer(MainActivity.this, -1);
                    refreshSelections();
                }
            });
        }
        b.show();
    }

    // ------------------------------------------------------------------ menu features

    private void showMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor);
        String[] names = {"Update", "Telegram", "VPN Share", "Split Tunneling", "IP Hunter",
                "Connection Log", "Exit"};
        for (int i = 0; i < names.length; i++) pm.getMenu().add(0, i, i, names[i]);
        pm.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case 0: showUpdate(); break;
                    case 1: openTelegram(); break;
                    case 2: shareApp(); break;
                    case 3: showSplitTunnel(); break;
                    case 4: ipHunter(); break;
                    case 5: showLog(); break;
                    case 6:
                        stopService(new Intent(MainActivity.this, BirukVpnService.class));
                        finish();
                        break;
                }
                return true;
            }
        });
        pm.show();
    }

    private void showUpdate() {
        new AlertDialog.Builder(this, R.style.DarkDialog)
                .setTitle("Update")
                .setMessage("Biruk VPN v1.0 (build 1)\nYou are on the latest build.")
                .setPositiveButton("OK", null)
                .show();
    }

    private void openTelegram() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(TELEGRAM_URL)));
        } catch (Exception e) {
            toast("No app can open this link");
        }
    }

    private void shareApp() {
        Intent s = new Intent(Intent.ACTION_SEND);
        s.setType("text/plain");
        s.putExtra(Intent.EXTRA_TEXT, "Try Biruk VPN - Secure | Fast | Anonymous");
        startActivity(Intent.createChooser(s, "Share Biruk VPN"));
    }

    private void showSplitTunnel() {
        if (busy()) return;
        toast("Loading apps...");
        new Thread(new Runnable() {
            @Override
            public void run() {
                PackageManager pm = getPackageManager();
                final List<String[]> apps = new ArrayList<String[]>();
                for (ApplicationInfo ai : pm.getInstalledApplications(0)) {
                    if (pm.getLaunchIntentForPackage(ai.packageName) != null
                            && !ai.packageName.equals(getPackageName())) {
                        apps.add(new String[]{String.valueOf(pm.getApplicationLabel(ai)), ai.packageName});
                    }
                }
                Collections.sort(apps, new Comparator<String[]>() {
                    @Override public int compare(String[] a, String[] b) { return a[0].compareToIgnoreCase(b[0]); }
                });
                runOnUiThread(new Runnable() {
                    @Override public void run() { showSplitDialog(apps); }
                });
            }
        }).start();
    }

    private void showSplitDialog(final List<String[]> apps) {
        Set<String> allowed = Store.getAllowedApps(this);
        String[] labels = new String[apps.size()];
        final boolean[] checked = new boolean[apps.size()];
        for (int i = 0; i < apps.size(); i++) {
            labels[i] = apps.get(i)[0];
            checked[i] = allowed.contains(apps.get(i)[1]);
        }
        new AlertDialog.Builder(this, R.style.DarkDialog)
                .setTitle("Split Tunneling: only checked apps use the VPN")
                .setMultiChoiceItems(labels, checked, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which, boolean isChecked) {
                        checked[which] = isChecked;
                    }
                })
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        Set<String> set = new HashSet<String>();
                        for (int i = 0; i < checked.length; i++) if (checked[i]) set.add(apps.get(i)[1]);
                        Store.setAllowedApps(MainActivity.this, set);
                        toast(set.isEmpty() ? "All apps use the VPN" : set.size() + " app(s) selected");
                    }
                })
                .setNeutralButton("All apps", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        Store.setAllowedApps(MainActivity.this, new HashSet<String>());
                        toast("All apps use the VPN");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void ipHunter() {
        toast("Checking public IP...");
        new Thread(new Runnable() {
            @Override
            public void run() {
                String result;
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL("https://api.ipify.org").openConnection();
                    c.setConnectTimeout(8000);
                    c.setReadTimeout(8000);
                    BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream()));
                    result = r.readLine();
                    r.close();
                } catch (Exception e) {
                    result = null;
                }
                final String ip = result;
                VpnState.log(ip != null ? "IP Hunter: public IP " + ip : "IP Hunter: lookup failed");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        new AlertDialog.Builder(MainActivity.this, R.style.DarkDialog)
                                .setTitle("IP Hunter")
                                .setMessage(ip != null ? "Public IP: " + ip : "Lookup failed. Check your connection.")
                                .setPositiveButton("OK", null)
                                .show();
                    }
                });
            }
        }).start();
    }

    private void showLog() {
        TextView t = new TextView(this);
        t.setTypeface(Typeface.MONOSPACE);
        t.setTextSize(12);
        t.setTextColor(0xFFCFE8FF);
        t.setPadding(32, 16, 32, 16);
        String log = VpnState.getLog();
        t.setText(log.length() == 0 ? "No events yet." : log);
        ScrollView sv = new ScrollView(this);
        sv.addView(t);
        new AlertDialog.Builder(this, R.style.DarkDialog)
                .setTitle("Connection Log")
                .setView(sv)
                .setPositiveButton("Close", null)
                .setNeutralButton("Clear", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { VpnState.clearLog(); }
                })
                .show();
    }

    // ------------------------------------------------------------------ helpers

    private String localIp() {
        String ip = "N/A";
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback() || ni.getName().startsWith("tun")) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) {
                        ip = a.getHostAddress();
                        break;
                    }
                }
                if (!ip.equals("N/A")) break;
            }
        } catch (Exception ignored) {
        }
        String type = "NET";
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo n = cm.getActiveNetworkInfo();
            if (n != null) type = n.getTypeName();
        } catch (Exception ignored) {
        }
        return "Local IP: " + ip + "-" + type;
    }

    private ListView makeList() {
        ListView lv = new ListView(this);
        lv.setDivider(new ColorDrawable(Color.TRANSPARENT));
        lv.setDividerHeight(16);
        lv.setPadding(24, 16, 24, 0);
        return lv;
    }

    private LinearLayout vbox() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(48, 16, 48, 0);
        return box;
    }

    private EditText addField(LinearLayout box, String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setSingleLine(true);
        box.addView(e);
        return e;
    }

    private static String clean(String s) {
        return s.replace("|", " ").replace("\n", " ").trim();
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }
}
