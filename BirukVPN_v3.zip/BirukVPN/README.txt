BIRUK VPN v3 - Android source (Java, no external dependencies)
===============================================================

WHAT WAS FIXED
The first ZIP used an old Android Gradle plugin (3.0.1, meant for AIDE). AndroidIDE
injects its own plugin ('com.itsaky.androidide') that needs a modern Gradle/AGP, so
it could not be resolved. This version uses the standard modern setup:
  Android Gradle Plugin 7.4.2, Gradle 7.5 (gradle/wrapper), compileSdk 33,
  namespace in app/build.gradle, plugins{} block, no IDE-specific plugin lines.

IMPORTANT
- Not compiled by me (no Android SDK here). If you get an error, send me the Build output.
- The app has NO built-in servers. It tunnels to YOUR server (server/biruk_server.py).
- The tunnel is a small custom TLS tunnel, not V2Ray/OpenVPN.
- Package host/SNI only changes the TLS host name sent in the handshake; any effect depends
  on your network. Using it to avoid carrier billing may break your carrier's terms.

BUILD IN ANDROIDIDE
1) Unzip BirukVPN_v3.zip to phone storage (e.g. /sdcard/AndroidIDEProjects/BirukVPN).
2) AndroidIDE > Open saved project > pick the BirukVPN folder (the one with settings.gradle).
3) Stay online for the first sync: it downloads Gradle 7.5 and the Android plugin.
4) Tap Run (play) to build and install the debug APK.

IF AndroidIDE STILL REJECTS THE BUILD FILES (most reliable fallback)
- In AndroidIDE create a NEW project (Empty Views Activity, Java, package com.biruk.vpn).
  It gets build files that match your AndroidIDE version.
- From this ZIP copy into the new project's app/src/main/ :
    java/com/biruk/vpn/*.java  -> replace the template's Java files (delete MainActivity template)
    res/                       -> merge (overwrite files with the same names)
    AndroidManifest.xml        -> replace
  Keep the new project's own build.gradle files, but make sure app/build.gradle has
  namespace 'com.biruk.vpn', minSdk 24, targetSdk 28, and that it does not need appcompat.
- If it says platform android-33 is missing, install it in AndroidIDE's SDK Manager, or change
  compileSdk in app/build.gradle to the platform you have.

SET UP THE SERVER (Linux VPS with root, Python 3)
  cd server
  openssl req -x509 -newkey rsa:2048 -nodes -keyout server.key -out server.crt -days 3650 -subj "/CN=biruk"
  openssl x509 -in server.crt -noout -fingerprint -sha256
  BIRUK_KEY="a-long-random-secret" BIRUK_PORT=443 python3 biruk_server.py

USE THE APP
- SERVER card > Add: name, host/IP, port, same access key, SHA-256 fingerprint from above.
- NETWORK card: pick a package; long-press to edit its host/SNI, or Add new ones.
- START connects (accept the Android VPN prompt). Bell icon / menu "Connection Log" shows events.
- Menu: Split Tunneling, IP Hunter, Update, Telegram, VPN Share, Exit.
- Set TELEGRAM_URL in MainActivity.java to your own channel.
