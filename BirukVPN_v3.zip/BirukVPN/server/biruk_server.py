#!/usr/bin/env python3
"""
Biruk VPN relay server (single client, Linux, run as root).
Matches the Android client: TLS, 2-byte length-prefixed raw IP packets,
first frame = access key, reply "OK".

Setup:
  openssl req -x509 -newkey rsa:2048 -nodes -keyout server.key -out server.crt -days 3650 -subj "/CN=biruk"
  openssl x509 -in server.crt -noout -fingerprint -sha256     # paste this into the app's server form
  BIRUK_KEY="your-long-secret" BIRUK_PORT=443 python3 biruk_server.py
"""
import hmac, os, select, socket, ssl, struct, subprocess, threading, fcntl

KEY = os.environ.get("BIRUK_KEY", "").encode()
PORT = int(os.environ.get("BIRUK_PORT", "443"))
IFNAME = b"biruk0"
TUNSETIFF = 0x400454CA
IFF_TUN, IFF_NO_PI = 0x0001, 0x1000


def sh(cmd):
    subprocess.call(cmd, shell=True)


def open_tun():
    fd = os.open("/dev/net/tun", os.O_RDWR)
    fcntl.ioctl(fd, TUNSETIFF, struct.pack("16sH", IFNAME, IFF_TUN | IFF_NO_PI))
    sh("ip addr add 10.8.0.1/24 dev biruk0")
    sh("ip link set biruk0 mtu 1400 up")
    sh("sysctl -w net.ipv4.ip_forward=1")
    sh("iptables -t nat -C POSTROUTING -s 10.8.0.0/24 ! -o biruk0 -j MASQUERADE 2>/dev/null || "
       "iptables -t nat -A POSTROUTING -s 10.8.0.0/24 ! -o biruk0 -j MASQUERADE")
    return fd


def recv_exact(c, n):
    buf = b""
    while len(buf) < n:
        chunk = c.recv(n - len(buf))
        if not chunk:
            raise EOFError
        buf += chunk
    return buf


def recv_frame(c):
    n = struct.unpack("!H", recv_exact(c, 2))[0]
    return recv_exact(c, n) if n else b""


def send_frame(c, data):
    c.sendall(struct.pack("!H", len(data)) + data)


def serve(conn, tun):
    stop = threading.Event()

    def tun_to_client():
        try:
            while not stop.is_set():
                r, _, _ = select.select([tun], [], [], 1.0)
                if r:
                    send_frame(conn, os.read(tun, 65535))
        except Exception:
            pass
        stop.set()

    t = threading.Thread(target=tun_to_client, daemon=True)
    t.start()
    try:
        while not stop.is_set():
            pkt = recv_frame(conn)
            if pkt:
                os.write(tun, pkt)
    except Exception:
        pass
    stop.set()
    t.join(2)
    conn.close()


def main():
    if not KEY:
        raise SystemExit("Set BIRUK_KEY to a long random secret first.")
    tun = open_tun()
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain("server.crt", "server.key")
    srv = socket.socket()
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("0.0.0.0", PORT))
    srv.listen(1)
    print("Listening on", PORT)
    while True:
        raw, addr = srv.accept()
        try:
            raw.settimeout(10)
            conn = ctx.wrap_socket(raw, server_side=True)
            if not hmac.compare_digest(recv_frame(conn), KEY):
                conn.close()
                continue
            send_frame(conn, b"OK")
            conn.settimeout(None)
        except Exception:
            try:
                raw.close()
            except Exception:
                pass
            continue
        print("Client connected:", addr)
        serve(conn, tun)
        print("Client disconnected")


if __name__ == "__main__":
    main()
